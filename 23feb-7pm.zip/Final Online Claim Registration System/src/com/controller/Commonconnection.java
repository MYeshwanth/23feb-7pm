package com.controller;

import java.sql.Connection;
import java.sql.DriverManager;

public class Commonconnection {
	public static Connection getCon() 
	   {
		   Connection c=null;
		   try{
		   Class.forName("oracle.jdbc.OracleDriver");
	c=DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521:orcl","trg610","training610");
		   //System.out.println("connected");
		      }
		   catch(Exception e)
		   {
			   System.out.println(e);
		   }
		   return c;
	}
}
