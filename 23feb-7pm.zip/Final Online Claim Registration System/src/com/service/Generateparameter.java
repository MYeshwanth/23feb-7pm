package com.service;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class Generateparameter extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		String cnforreport=request.getParameter("cno");
		int cnfn=Integer.parseInt(cnforreport);
		HttpSession session30=request.getSession(true);
		session30.setAttribute("cnf",cnfn);
		System.out.println(cnforreport);
		RequestDispatcher rd=null;
		rd=request.getRequestDispatcher("/generatereportfinal.jsp");
		rd.forward(request, response);
		
}}
